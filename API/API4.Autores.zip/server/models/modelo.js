const mongoose = require('mongoose');

const esquemaAut  = new mongoose.Schema({
        nombre: {
            type:String,
            required:[true,'campo requerido'],
            minlength:[3,'El largo menor permitido es de 5 carectares'],
            maxlength:[50,'El largo mayor permitido es de 50 carectares']
        }
    },{timestamps:true})

const Autor = mongoose.model('esq_Aut', esquemaAut);

module.exports = Autor;