const mongoose = require('mongoose');
mongoose.connect('mongodb://localhost/db_Autor', {useNewUrlParser: true});
module.exports = mongoose;





