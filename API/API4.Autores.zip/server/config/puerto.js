module.exports = (app) =>{

    app.listen(8000, ()=>{
        console.log("Servidor escuchando el puerto 8000");
    });
    
};
