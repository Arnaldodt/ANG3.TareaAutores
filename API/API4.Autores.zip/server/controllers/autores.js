const Autores  = require("../models/modelo");

const classAutor = {
    Trae: async (req, res) => {    
        try{
            const data = await Autores.find().sort({nombre:1})
            if (data !== null){
                res.json({existen:'2',mensajes:data})
            } else {
                res.json({existen:'1'})
            }
        }
        catch (err){
            res.json({existen:'0',error:err})
        }
    },
    Buscar: async (req, res) => {    
        const id = req.params.id
        try{
            const data = await Autores.find({_id:id})
            if (data !== null){
                res.json({existen:'2',mensajes:data})
            } else {
                res.json({existen:'1'})
            }
        }
        catch (err){
            res.json({existen:'0',error:err})
        }
    },
    Crea: async(req, res) => {   
        const AUT = new Autores;
        AUT.nombre = req.body.nombre

        try{
            const data = await Autores.create(AUT)
            res.json({existen:'1'})
        }
        catch (err){
            res.json({existen:'0',error:err})
        }
    },
    Actualiza: async(req, res) => {   
        const id = req.params.id
        let nombre = req.body.nombre
        try{
            const data = await Autores.updateOne({_id:id}, {nombre})
            res.json({existen:'1'})
        }
        catch (err){
            res.json({existen:'0',error:err})
        }
    },
    Elimina: async (req, res) => {    
        const ID = req.params.id

        try{
            const data = await Autores.deleteOne({_id:ID})
            res.json({existen:'1'})
        }
        catch (err){
            res.json({existen:'0',error:err})
        }
    }
}

module.exports = classAutor;