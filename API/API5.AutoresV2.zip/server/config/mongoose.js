const mongoose = require('mongoose');
mongoose.connect('mongodb://localhost/db_AutorV2', {useNewUrlParser: true});
module.exports = mongoose;





