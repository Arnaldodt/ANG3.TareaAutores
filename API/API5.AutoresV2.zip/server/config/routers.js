const exp = require("express");
const router = exp.Router();

const {body , validationResult} = require('express-validator');

const valAUT = require("../controllers/autores")

router.get('/', (req, res) => valAUT.Trae(req, res));

router.post('/CAutor', [
    body('nombre','Ingrese Nombre, entre 3 a 50 caracteres.')
        .exists()
        .isLength({min:3})
        .isLength({max:50})
], (req, res) => {
    const errores = validationResult(req)
    if (!errores.isEmpty())
    {
        let arrErr = errores.array();
        res.json({existen:'0',error:arrErr})
    }
    else {    
        valAUT.Crea(req, res)
    }
});

router.post('/CCita/:id', [
    body('cita','Ingrese Nombre, entre 3 a 50 caracteres.')
        .exists()
        .isLength({min:3})
        .isLength({max:50})
], (req, res) => {
    const errores = validationResult(req)
    if (!errores.isEmpty())
    {
        let arrErr = errores.array();
        res.json({existen:'0',error:arrErr})
    }
    else {    
        valAUT.CreaCita(req, res)
    }
});
router.delete('/ECita/:id1-:id2',  (req,res) => {valAUT.EliminaCita(req, res)});

router.put('/ACitaVoto/:id1-:id2',  (req,res) => {valAUT.AumentaVotoCita(req, res)});
router.put('/DCitaVoto/:id1-:id2',  (req,res) => {valAUT.DisminuyeVotoCita(req, res)});


router.put('/AAutor/:id', [
    body('nombre','Ingrese Nombre, entre 3 a 50 caracteres.')
        .exists()
        .isLength({min:3})
        .isLength({max:50})
],  (req,res) => {
    const errores = validationResult(req)
    if (!errores.isEmpty())
    {
        let arrErr = errores.array();
        res.json({existen:'0',error:arrErr})
    }
    else {
        valAUT.Actualiza(req, res)
    }
});

router.get('/BAutor/:id', (req, res) => {valAUT.Buscar(req, res)});
router.delete('/EAutor/:id',  (req,res) => {valAUT.Elimina(req, res)});

module.exports = router;