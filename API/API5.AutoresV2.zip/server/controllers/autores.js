const Autores  = require("../models/modelo");

const classAutor = {
    Trae: async (req, res) => {    
        try{
            const data = await Autores.find().sort({nombre:1})
            if (data !== null){
                res.json({existen:'2',mensajes:data})
            } else {
                res.json({existen:'1'})
            }
        }
        catch (err){
            res.json({existen:'0',error:err})
        }
    },
    Buscar: async (req, res) => {    
        const id = req.params.id
        try{
            const data = await Autores.find({_id:id})
            if (data !== null){
                res.json({existen:'2',mensajes:data})
            } else {
                res.json({existen:'1'})
            }
        }
        catch (err){
            res.json({existen:'0',error:err})
        }
    },
    Crea: async(req, res) => {   
        const AUT = new Autores;
        AUT.nombre = req.body.nombre

        try{
            const data = await Autores.create(AUT)
            res.json({existen:'1'})
        }
        catch (err){
            res.json({existen:'0',error:err})
        }
    },

    CreaCita: async(req, res) => {   
        const id = req.params.id
     
        try{
            const data = await Autores.updateOne({_id:id},{$push:{citas:{cita:req.body.cita}}})
            res.json({existen:'1'})
        }
        catch (err){
            res.json({existen:'0',error:err})
        }
    },

    EliminaCita: async (req, res) => {    
        const ID_AUT = req.params.id1
        const ID_CIT = req.params.id2
        try{
            const data = await Autores.updateOne({_id:ID_AUT},{$pull:{citas:{_id:ID_CIT}}})
            res.json({existen:'1'})
        }
        catch (err){
            res.json({existen:'0',error:err})
        }
    },

    AumentaVotoCita: async (req, res) => {    
        const ID_AUT = req.params.id1
        const ID_CIT = req.params.id2
        console.log(ID_AUT)
        console.log(ID_CIT)
        try{
            const data = await Autores.updateOne({_id:ID_AUT}, {$inc:{'citas.$[si].votos':1}} , {"arrayFilters" :[ { "si._id" :ID_CIT} ]} )
            res.json({existen:'1'})
        }
        catch (err){
            console.log(err)
            res.json({existen:'0',error:err})
        }
    },
    DisminuyeVotoCita: async (req, res) => {    
        const ID_AUT = req.params.id1
        const ID_CIT = req.params.id2
        try{
            const data = await Autores.updateOne({_id:ID_AUT}, {$inc:{'citas.$[si].votos':-1}} , {"arrayFilters" :[ { "si._id" :ID_CIT} ]} )
            res.json({existen:'1'})
        }
        catch (err){
            res.json({existen:'0',error:err})
        }
    },


    Actualiza: async(req, res) => {   
        const id = req.params.id
        let nombre = req.body.nombre
        try{
            const data = await Autores.updateOne({_id:id}, {nombre})
            res.json({existen:'1'})
        }
        catch (err){
            res.json({existen:'0',error:err})
        }
    },
    Elimina: async (req, res) => {    
        const ID = req.params.id

        try{
            const data = await Autores.deleteOne({_id:ID})
            res.json({existen:'1'})
        }
        catch (err){
            res.json({existen:'0',error:err})
        }
    }
}

module.exports = classAutor;