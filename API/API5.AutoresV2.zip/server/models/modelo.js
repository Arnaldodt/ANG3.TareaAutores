const mongoose = require('mongoose');

const esquemaCita  = new mongoose.Schema({
    cita: {
        type:String,
        required:[true,'campo requerido'],
        minlength:[3,'El largo menor permitido es de 5 carectares'],
        maxlength:[50,'El largo mayor permitido es de 50 carectares'] 
    },
    votos:{type:Number,default:0}
},{timestamps:true})

const esquemaAut  = new mongoose.Schema({
        nombre: {
            type:String,
            required:[true,'campo requerido'],
            minlength:[3,'El largo menor permitido es de 5 carectares'],
            maxlength:[50,'El largo mayor permitido es de 50 carectares']
        },
        citas:[esquemaCita]
    },{timestamps:true})

const Autor = mongoose.model('esq_AutV2', esquemaAut);

module.exports = Autor;